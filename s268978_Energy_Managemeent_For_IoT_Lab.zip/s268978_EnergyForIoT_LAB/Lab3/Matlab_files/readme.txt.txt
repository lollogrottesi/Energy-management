LoadSimulink.m and config.m are the two files to execute in order to fill the simulink model.

Simulink model has been exported in a compatible version (2018a). Three different model has been used.

- Simulation_2018a, original simualtion circuit (used also for workload tests)
- Simulation_2018a_PV, dual PV cells test model.
- Simulation_2018a_BATT, dual battery model.
- simulation_2018a_MULTI_BATT_MULTI_PV, multiple battery and multiple PV cell model.

All the multi-model are left in parallel configuration.

ResultPlot.m is the file used for the result plot.