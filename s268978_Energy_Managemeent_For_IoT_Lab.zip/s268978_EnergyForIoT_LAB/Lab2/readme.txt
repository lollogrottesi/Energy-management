The file working with the dataset are:
datasetEnergyDistance - exctract power consumption and distances (LAB, SSIM) for all images.
ImageEnergySaving     - algorithm tent to optimize the power consumption of the dataset, distance cnstraint (1%, 5%, 10%).
OLEDEnergySaving      - algorithm tent to optimize the power consumption of the dataset,using DVS and considering the OLED emulation, distance cnstraint (1%, 5%, 10%).